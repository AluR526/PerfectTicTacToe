//click click click
//entr words in difficulty level
//First Move = super long
//Two == move equals choose
//Sleep

package alu;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * TacToe
 * @author Ryan Alu, Saint Francis University
 * Sep 26, 2017
 */

public class TacTester
{
    public static void main (String [] args)
    {
        int choice = 0;
        
        //Start the game up and open interface.
        Tac game = new Tac();
        game.initialize();
        game.controller();
        
        while(!game.finalSituation())
        //While the game is not over ask the player where he wants to move and save his choice to int choice. Do not continue until user clicked a button.    
        {
            game.moveReset();
            System.out.println(game.getMove());
            while(game.getMove() == 99)
            {
                choice = game.getMove();
                //Delay a second
                try
                {
                    TimeUnit.SECONDS.sleep(1);
                } 
                catch (InterruptedException ex)
                {
                    Logger.getLogger(TacTester.class.getName()).log(Level.SEVERE, null, ex);
                }          
            }
            choice = game.getMove();
            System.out.println(game.getMove());
            
                        
            
            while(!game.legalMove(choice))
            //If the player did not pick a legal move, wait until he does so.    
            {
                game.moveReset();
                while(game.getMove() == 99)
                {
                    choice = game.getMove();
                    try
                    {
                        TimeUnit.SECONDS.sleep(1);
                    } 
                    catch (InterruptedException ex)
                    {
                        Logger.getLogger(TacTester.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                choice = game.getMove();
            }
            game.updateGame(choice);
            
            if(!game.finalSituation())
            //If the game is not over let the computer go.
            {
                game.updateGame(game.computerMove());
            }
            
        }
        //Game is over. Display text box of result.
        game.result();        
    }
}   


