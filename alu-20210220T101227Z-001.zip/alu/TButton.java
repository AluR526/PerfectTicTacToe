package alu;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 * TacToe
 * @author Ryan Alu, Saint Francis University
 * Oct 25, 2017
 */

public class TButton extends JButton
{
   public int ident;
   public boolean isClicked;
}   
