package alu;

/**
 * TacToe
 * @author Ryan Alu, Saint Francis University
 * Oct 20, 2017
 */

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.*;

public class Gui extends JFrame implements ActionListener
{
    private TButton buttons[];
    private final String names[] = {"1","2","3","4","5","6","7","8","9"};
    private boolean toggle = true;
    private Container container;
    private GridLayout grid;
    private int f;
    
    public Gui()
    {
        super();
        grid = new GridLayout(3,3,5,5);
        container = getContentPane();
        setLayout(grid);
        buttons = new TButton[9];
        
        for(int count=0; count<9; count++)
        {
            buttons[count] = new TButton();
            buttons[count].ident = count;
            buttons[count].isClicked = false;
            buttons[count].addActionListener(this);
            add(buttons[count]);
        }
    }

    /*
    public int buttonToNumber()
    {
       int j =0;
       while(j == 0);
       {
            for(int i=0; i<9; i++)
            {
                if(buttons[i].isEnabled() == true)
                {
                    return i+1;
                }
            }
       } 
    }
*/
    /*@Override
    public void actionPerformed(ActionEvent e)
    {
       int j =0;
       while(j == 0);
       {
            for(int i=0; i<9; i++)
            {
                if(buttons[i].isEnabled() == true)
                {
                    f = i+1;
                }
            }
       } 
    }*/
    
    @Override
    public void actionPerformed(ActionEvent e)
    {
        TButton currentButton = (TButton)(e.getSource());
        move = currentButton.ident;
        currentButton.isClicked = true;
        currentButton.setText("X");
        
        
        System.out.println(move);
        
        
           
    }
}    
    
    //public int getF()
    //{
      //  return f;
    //}
//}   
