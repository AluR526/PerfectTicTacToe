package alu;

/**
 * TacToe
 * @author Ryan Alu, Saint Francis University
 * Oct 23, 2017
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.*;

public class GuiTester
{
    public static void Main (String [] args)
    {
               
        
        
        Gui gridlay = new Gui();
        gridlay.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gridlay.setSize(300,300);
        gridlay.setVisible(true);
        
        
    }
}   




package alu;

import java.util.Scanner;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 * TacToe
 * @author Ryan Alu, Saint Francis University
 * Sep 26, 2017
 */


public class Tac extends JFrame
{
//Instance Fields
//Consists of creating the board (an array) that holds strings, player name, level of dificulty of computer, and the turn counter.
    private static final int MAX = 10;
    private String[] board;
    private String name;
    private int level;
    private int counter;   
    
//Constructor
// Board array has 10 spaces, name is and empty string, level equals an invalid number 99 (will be changed) and counter naturally starts at one.
    public Tac()
    {
       board = new String[MAX];
       name = "";
       level = 99;
       counter = 1;
    }
//Takes a deep copy of the current situation.    
    public Tac(Tac original)
    {
        name = original.name;
        level = original.level;
        counter = original.counter;
        board = new String[MAX];
        for (int i = 1; i < MAX; i++)
            board[i] = original.board[i];   
    }
//Methods
    public void initialize()
    //Sets up the game.
    {
        //Inserts values into board array.
        board[1] = "1";
        board[2] = "2";
        board[3] = "3";
        board[4] = "4";
        board[5] = "5";
        board[6] = "6";
        board[7] = "7";
        board[8] = "8";
        board[9] = "9";
        
        //Asks user for name and welcomes him.
        Scanner input = new Scanner (System.in);
        System.out.println("What is your name challenger?");
        name = input.next();
        System.out.println("Welcome " + name);
        System.out.println();
        
        
        
        

//User selects difficulty (must be between 0 and 8 inclusive)
 System.out.println("Choose Difficulty");
        while(level <0 || level >8)
        {
            level = input.nextInt();
        }
       
        
    }//initialize
        
    public void printBoard()
    //Prints a tic tac toe board
    {
        System.out.println(board[1] + "|" + board[2] + "|" + board[3]);
        System.out.println(board[4] + "|" + board[5] + "|" + board[6]);
        System.out.println(board[7] + "|" + board[8] + "|" + board[9]);
    }//printBoard

    public boolean whoseMove()
    //Returns true if it is the users mover (counter is odd).
    {
        return counter % 2 == 1;
    }//whoseMove()
    
    public boolean legalMove(int pos)
    {
    //Determines if a move is legal. A move is legal if it is on the board (between 1 and 9) and if the spot is not already taken by an X or O.
        return !(pos>9 || pos<1 || board[pos].equals("X") || board[pos].equals("O"));
    }//legalMove
    
    public void updateGame(int spot)
    {
    //Updates the game with a move. X if it's the players move and O if its the computers move. Based on whoseMove which is based on the counter.
        if (whoseMove())
        {
            board[spot] = "X";
        }
        else
        {
            board[spot] = "O";
        }
        counter++;
    }//updateGame
    
    public boolean finalSituation()
    {
    //Determines if the game is over. Game is over if there is a three in a row of X's or O's or if 9 moves have been made (a tie).
        return (board[1].equals("X") && board[2].equals("X") && board[3].equals("X")) ||
                (board[4].equals("X") && board[5].equals("X") && board[6].equals("X")) ||
                (board[7].equals("X") && board[8].equals("X") && board[9].equals("X")) ||
                (board[1].equals("X") && board[5].equals("X") && board[9].equals("X")) ||
                (board[1].equals("X") && board[4].equals("X") && board[7].equals("X")) ||
                (board[2].equals("X") && board[5].equals("X") && board[8].equals("X")) ||
                (board[3].equals("X") && board[6].equals("X") && board[9].equals("X")) ||
                (board[3].equals("X") && board[5].equals("X") && board[7].equals("X")) ||
                (board[1].equals("O") && board[2].equals("O") && board[3].equals("O")) ||
                (board[4].equals("O") && board[5].equals("O") && board[6].equals("O")) ||
                (board[7].equals("O") && board[8].equals("O") && board[9].equals("O")) ||
                (board[1].equals("O") && board[5].equals("O") && board[9].equals("O")) ||
                (board[3].equals("O") && board[5].equals("O") && board[7].equals("O")) ||
                (board[1].equals("O") && board[4].equals("O") && board[7].equals("O")) ||
                (board[2].equals("O") && board[5].equals("O") && board[8].equals("O")) ||
                (board[3].equals("O") && board[6].equals("O") && board[9].equals("O")) ||
                counter>MAX;
    }
    
    public int playerMove()
    {
    //Asks where the user wants to move and recieves the number the user picks.
        Scanner enter = new Scanner (System.in);
        System.out.println("Where do you chose to play your move, " + name + " ?");
        return enter.nextInt();
    }//playerMove()
    
    public int computerMove()
    {
    //computer goes where it thinks best. See bestMove().
        return bestMove();
    }//computerMove
    
    public int judge()
    {
    //Used for the computer to figure out what move is good and what move is bad to make
        //If the player wins return a 0 (that's a bad outcome).
        if((board[1].equals("X") && board[2].equals("X") && board[3].equals("X")) ||
           (board[4].equals("X") && board[5].equals("X") && board[6].equals("X")) ||
           (board[7].equals("X") && board[8].equals("X") && board[9].equals("X")) ||
           (board[1].equals("X") && board[5].equals("X") && board[9].equals("X")) ||
           (board[1].equals("X") && board[4].equals("X") && board[7].equals("X")) ||
           (board[2].equals("X") && board[5].equals("X") && board[8].equals("X")) ||
           (board[3].equals("X") && board[6].equals("X") && board[9].equals("X")) ||
           (board[3].equals("X") && board[5].equals("X") && board[7].equals("X")))
        {
            return 0;
        }
        //If the computer wins retuen 100 (that's a good outcome).
        else if((board[1].equals("O") && board[2].equals("O") && board[3].equals("O")) ||
           (board[4].equals("O") && board[5].equals("O") && board[6].equals("O")) ||
           (board[7].equals("O") && board[8].equals("O") && board[9].equals("O")) ||
           (board[1].equals("O") && board[5].equals("O") && board[9].equals("O")) ||
           (board[3].equals("O") && board[5].equals("O") && board[7].equals("O")) ||
           (board[1].equals("O") && board[4].equals("O") && board[7].equals("O")) ||
           (board[2].equals("O") && board[5].equals("O") && board[8].equals("O")) ||
           (board[3].equals("O") && board[6].equals("O") && board[9].equals("O")))
        {
            return 100;
        }
        //Other wise just return 50. Do not know if it is a good or bad move.
        else
        {
            return 50;
        }
    }
    
    public void result()
    {
    //Display a message at the end of a game.
        //If the player gets three in a row print out that the player won!
        if((board[1].equals("X") && board[2].equals("X") && board[3].equals("X")) ||
           (board[4].equals("X") && board[5].equals("X") && board[6].equals("X")) ||
           (board[7].equals("X") && board[8].equals("X") && board[9].equals("X")) ||
           (board[1].equals("X") && board[5].equals("X") && board[9].equals("X")) ||
           (board[1].equals("X") && board[4].equals("X") && board[7].equals("X")) ||
           (board[2].equals("X") && board[5].equals("X") && board[8].equals("X")) ||
           (board[3].equals("X") && board[6].equals("X") && board[9].equals("X")) ||
           (board[3].equals("X") && board[5].equals("X") && board[7].equals("X")))
        {
            System.out.println();
            System.out.println(name + " WINS!");
        //If the computer gets three in a row print out that the computer won!
        }
        else if((board[1].equals("O") && board[2].equals("O") && board[3].equals("O")) ||
           (board[4].equals("O") && board[5].equals("O") && board[6].equals("O")) ||
           (board[7].equals("O") && board[8].equals("O") && board[9].equals("O")) ||
           (board[1].equals("O") && board[5].equals("O") && board[9].equals("O")) ||
           (board[3].equals("O") && board[5].equals("O") && board[7].equals("O")) ||
           (board[1].equals("O") && board[4].equals("O") && board[7].equals("O")) ||
           (board[2].equals("O") && board[5].equals("O") && board[8].equals("O")) ||
           (board[3].equals("O") && board[6].equals("O") && board[9].equals("O")))
        {
            System.out.println();
            System.out.println("Computer WINS!");
        }
        //If no one won, print out it was a tie.
        else
        {
            System.out.println();
            System.out.println("TIE!");
        }
    }
    
    
    public int bestMove()
    {
    //Calls best guess and returns where the computer should move.
        int v, w;
        int best;
        int tryMove = 0;
        Tac tempSituation;
        
        //Create a copy of the game.
        tempSituation = new Tac(this);
        
        //Get the first legal move (there is at least one).
        for(int i=1; i<MAX; i++)
        {
            if(legalMove(i))
            {
                tryMove = i;
                break;
            } 
        }
        
        //Update the copy of the game with the first legal move and evaluate the situation.
        tempSituation.updateGame(tryMove);
        v = tempSituation.bestGuess(level);
        best = tryMove;
        tryMove++;
        
        //Process all remaining possible moves.
        while(tryMove < MAX)
        {
            //Get the next legal move.
            for(; tryMove < MAX; tryMove++)
            {
                if(legalMove(tryMove))
                    break;
            }
            if (tryMove == MAX) break;
            
            //Make a copy of the situation and try the move that was just found.
            tempSituation = new Tac(this);
            tempSituation.updateGame(tryMove);
            
            w = tempSituation.bestGuess(level);
            
            //Update v and best the most recent move was better.
            if((!whoseMove() && (w > v)) || ((whoseMove()) && (w < v)))
            {
                v = w;
                best = tryMove;
            }
            //Go again until tryMove is outside the possible choices (past 9).
            tryMove++;
        }
        return best;
    }//bestMove
            
    public int bestGuess(int level)
    {
    //Looks ahead and determines what move is the best to take.
        int tryMove = 0;
        int v, w;
        Tac tempSituation;
    
        //If the difficulty is set to zero. Just have the computer take the next availabke move in order from position 1-9.
        if((level == 0) || finalSituation())
        {
            return judge();
        }
        else
        {
            //Create copy of game.
            tempSituation = new Tac(this);
            
            //Get the first legal move (there is at least one).
            for(int i=1; i<MAX; i++)
            {
                if(legalMove(i))
                {
                    tryMove = i;
                    break;
                } 
            }
            //Update the copy of the game with the first legal move and evaluate the situation. Go down a level because there are 1 less spots to look in the future to.
            tempSituation.updateGame(tryMove);
            v = tempSituation.bestGuess(level - 1);
            tryMove++;
            
            //Process all remaining possible moves.
            while(tryMove < MAX)
            {
                //Get the next legal move.
                for(; tryMove <MAX; tryMove++)
                {
                    if(legalMove(tryMove))
                    {
                        break;
                    }
                }
                if (tryMove == MAX) break;
                
                //Make a copy of the situation and try the move that was just found.
                tempSituation = new Tac(this);
                tempSituation.updateGame(tryMove);
                
                w = tempSituation.bestGuess(level - 1);
                
                //Update v. v will be the value of the best guess.
                if(!whoseMove())
                {
                    if (v<w)
                    {
                        v = w;
                    }
                    else
                    {
                        v = v;
                    }
                }
                else
                {
                    if(v<w)
                    {
                        v = v;
                    }
                    else
                    {
                        v = w;
                    }
                }
                tryMove++;
            }
            return v;
        }
    }//bestguess
}//Tac















public class TacTester
{
    public static void main (String [] args)
    {
        int choice;
        Scanner enter = new Scanner (System.in);
        
        //Start the game up and show the board
        Tac game = new Tac();
        game.initialize();
        game.printBoard();
        
        while(!game.finalSituation())
        //While the game is not over ask the player where he wants to move and save his choice to int choice.
        {
            System.out.println("Where do you chose to play your move?");
            choice = enter.nextInt();            
            
            while(!game.legalMove(choice))
            //If the player did not pick a legal move, ask again.
            {
                game.printBoard();
                System.out.println("Where do you chose to play your move?");
                choice = enter.nextInt();
            }
            
            //Update the game and print the board.
            game.updateGame(choice);
            game.printBoard();
            System.out.println();
            
            
            if(!game.finalSituation())
            //If the game is not over let the computer go.
            {
                game.updateGame(game.computerMove());
            }
            game.printBoard();
        }
        //Game is over. Show the final board and give the result.
        System.out.println("Final Board Outcome");
        game.result();
    }
    
}










int num = 1;
        for(int j=1; j<size; j++)
        {
            int space = 0;
            for(int i=1; i<size; i++)
            {
                if(num<10 && num>0)
                {
                    System.out.print("X" + " " + board[num] + " ");
                    num++;
                }
                else if(num>=10 && num<=99)
                {
                    System.out.print("X" + board[num] + " ");
                    num++;
                }
                else
                {
                    System.out.print("X" + board[num]);
                    num++;
                }
                
            }
            System.out.println("X");
            for(int k=1; k<=size+1; k++)
            {
                System.out.print(num);
                if(space<8)
                {
                    System.out.print(" ");
                    space++;
                }
                num++;
            }
            System.out.println();
        }





int num = 1;
        for(int j=1; j<size; j++)
        {
            for(int i=1; i<size; i++)
            {
                if(num>0 && num<10)
                {
                    System.out.print("X" + "   " + board[num] + "   ");
                    num++;
                }
                else if(num>=10 && num<=99)
                {
                    System.out.print("X" + "  " + board[num] + "  ");
                    num++;
                }
                else
                {
                    System.out.print("X" + " " + board[num] + " ");
                    num++;
                }
                
            }
            System.out.println("X");
            for(int k=1; k<size; k++)
            {
                System.out.print(num);
                if(num>0 && num<10)
                {
                    System.out.print("       ");
                    num++;
                }
                else if(num>=10 && num<=99)
                {
                    System.out.print("     ");
                    num++;
                }
                else
                {
                    System.out.print("   ");
                    num++;
                }
            }
            System.out.println(num);
            num++;
        }
        
        for(int i=1; i<size; i++)
            {
                if(num>0 && num<10)
                {
                    System.out.print("X" + "   " + board[num] + "   ");
                    num++;
                }
                else if(num>=10 && num<=99)
                {
                    System.out.print("X" + "  " + board[num] + "  ");
                    num++;
                }
                else
                {
                    System.out.print("X" + " " + board[num] + " ");
                    num++;
                }
            }
            System.out.println("X");













 
        
        
        
        
        
        
        
        
        
        
        if(size == 2)
        {
            System.out.print("X" + " " + board[1] + " " + "X" + "\n");
            System.out.print(board[2] + "   " + board [3] + "\n");
            System.out.print("X" + " " + board[4] + " " + "X");
        }
        
        if(size == 3)
        {
            System.out.print("X" + " " + board[1] + " " + "X" + " " + board[2] + " " + "X" + "\n");
            System.out.print(board[3] + "   " + board [4] + "   " + board[5] + "\n");
            System.out.print("X" + " " + board[6] + " " + "X" + " " + board[7] + " " + "X" + "\n");
            System.out.print(board[8] + "   " + board [9] + "   " + board[10] + "\n");
            System.out.print("X" + " " + board[11] + " " + "X" + " " + board[12] + " " + "X" + "\n");
        }











if (size == 2)
        {
            f=1;
            if(attempt == 1 || attempt == 2 || attempt == 3 || attempt == 4)
            {
                bigBoxCounter[1]++;
            }
        }
        if (size == 3)
        {
            if(attempt == 1 || attempt == 3 || attempt == 4 || attempt == 6)
            {
                bigBoxCounter[1]++;
            }
            if(attempt == 2 || attempt == 4 || attempt == 5 || attempt == 7)
            {
                bigBoxCounter[2]++;
            }
            if(attempt == 6 || attempt == 8 || attempt == 9 || attempt == 11)
            {
                bigBoxCounter[3]++;
            }
            if(attempt == 7 || attempt == 9 || attempt == 10 || attempt == 12)
            {
                bigBoxCounter[4]++;
            }
        }
        if (size == 4)
        {
            if(attempt == 1 || attempt == 4 || attempt == 5 || attempt == 8)
            {
                bigBoxCounter[1]++;
            }
            if(attempt == 2 || attempt == 5 || attempt == 6 || attempt == 9)
            {
                bigBoxCounter[2]++;
            }
            if(attempt == 3 || attempt == 6 || attempt == 7 || attempt == 10)
            {
                bigBoxCounter[3]++;
            }
            if(attempt == 8 || attempt == 11 || attempt == 12 || attempt == 15)
            {
                bigBoxCounter[4]++;
            }
            if(attempt == 9 || attempt == 12 || attempt == 13 || attempt == 16)
            {
                bigBoxCounter[5]++;
            }
            if(attempt == 10 || attempt == 13 || attempt == 14 || attempt == 17)
            {
                bigBoxCounter[6]++;
            }
            if(attempt == 15 || attempt == 18 || attempt == 19 || attempt == 22)
            {
                bigBoxCounter[7]++;
            }
            if(attempt == 16 || attempt == 19 || attempt == 20 || attempt == 23)
            {
                bigBoxCounter[8]++;
            }
            if(attempt == 17 || attempt == 20 || attempt == 21 || attempt == 24)
            {
                bigBoxCounter[9]++;
            }
        }
        if (size == 5)
        {
            if(attempt == 1 || attempt == 5 || attempt == 6 || attempt == 10)
            {
                bigBoxCounter[1]++;
            }
            if(attempt == 2 || attempt == 6 || attempt == 7 || attempt == 11)
            {
                bigBoxCounter[2]++;
            }
            if(attempt == 3 || attempt == 7 || attempt == 8 || attempt == 12)
            {
                bigBoxCounter[3]++;
            }
            if(attempt == 4 || attempt == 8 || attempt == 9 || attempt == 13)
            {
                bigBoxCounter[4]++;
            }
            if(attempt == 10 || attempt == 14 || attempt == 15 || attempt == 19)
            {
                bigBoxCounter[5]++;
            }
            if(attempt == 11 || attempt == 15 || attempt == 16 || attempt == 20)
            {
                bigBoxCounter[6]++;
            }
            if(attempt == 12 || attempt == 16 || attempt == 17 || attempt == 21)
            {
                bigBoxCounter[7]++;
            }
            if(attempt == 13 || attempt == 17 || attempt == 18 || attempt == 22)
            {
                bigBoxCounter[8]++;
            }
            if(attempt == 19 || attempt == 23 || attempt == 24 || attempt == 28)
            {
                bigBoxCounter[9]++;
            }
            if(attempt == 20 || attempt == 24 || attempt == 25 || attempt == 29)
            {
                bigBoxCounter[10]++;
            }
            if(attempt == 21 || attempt == 25 || attempt == 26 || attempt == 30)
            {
                bigBoxCounter[11]++;
            }
            if(attempt == 22 || attempt == 26 || attempt == 27 || attempt == 31)
            {
                bigBoxCounter[12]++;
            }
            if(attempt == 28 || attempt == 32 || attempt == 33 || attempt == 37)
            {
                bigBoxCounter[13]++;
            }
            if(attempt == 29 || attempt == 33 || attempt == 34 || attempt == 38)
            {
                bigBoxCounter[14]++;
            }
            if(attempt == 30 || attempt == 34 || attempt == 35 || attempt == 39)
            {
                bigBoxCounter[15]++;
            }
            if(attempt == 31 || attempt == 35 || attempt == 36 || attempt == 40)
            {
                bigBoxCounter[16]++;
            }
        }
        if (size == 6)
        {
            if(attempt == 1 || attempt == 6 || attempt == 7 || attempt == 12)
            {
                bigBoxCounter[1]++;
            }
            if(attempt == 2 || attempt == 7 || attempt == 8 || attempt == 13)
            {
                bigBoxCounter[2]++;
            }
            if(attempt == 3 || attempt == 8 || attempt == 9 || attempt == 14)
            {
                bigBoxCounter[3]++;
            }
            if(attempt == 4 || attempt == 9 || attempt == 10 || attempt == 15)
            {
                bigBoxCounter[4]++;
            }
            if(attempt == 5 || attempt == 10 || attempt == 11 || attempt == 16)
            {
                bigBoxCounter[5]++;
            }
            if(attempt == 12 || attempt == 17 || attempt == 18 || attempt == 23)
            {
                bigBoxCounter[6]++;
            }
            if(attempt == 13 || attempt == 18 || attempt == 19 || attempt == 24)
            {
                bigBoxCounter[7]++;
            }
            if(attempt == 14 || attempt == 19 || attempt == 20 || attempt == 25)
            {
                bigBoxCounter[8]++;
            }
            if(attempt == 15 || attempt == 20 || attempt == 21 || attempt == 26)
            {
                bigBoxCounter[9]++;
            }
            if(attempt == 16 || attempt == 21 || attempt == 22 || attempt == 27)
            {
                bigBoxCounter[10]++;
            }
            if(attempt == 23 || attempt == 28 || attempt == 29 || attempt == 34)
            {
                bigBoxCounter[11]++;
            }
            if(attempt == 24 || attempt == 29 || attempt == 30 || attempt == 35)
            {
                bigBoxCounter[12]++;
            }
            if(attempt == 25 || attempt == 30 || attempt == 31 || attempt == 36)
            {
                bigBoxCounter[13]++;
            }
            if(attempt == 26 || attempt == 31 || attempt == 32 || attempt == 37)
            {
                bigBoxCounter[14]++;
            }
            if(attempt == 27 || attempt == 32 || attempt == 33 || attempt == 38)
            {
                bigBoxCounter[15]++;
            }
            if(attempt == 34 || attempt == 39 || attempt == 40 || attempt == 45)
            {
                bigBoxCounter[16]++;
            }
            if(attempt == 35 || attempt == 40 || attempt == 41 || attempt == 46)
            {
                bigBoxCounter[17]++;
            }
            if(attempt == 36 || attempt == 41 || attempt == 42 || attempt == 47)
            {
                bigBoxCounter[18]++;
            }
            if(attempt == 37 || attempt == 42 || attempt == 43 || attempt == 48)
            {
                bigBoxCounter[19]++;
            }
            if(attempt == 38|| attempt == 43 || attempt == 44 || attempt == 49)
            {
                bigBoxCounter[20]++;
            }
            if(attempt == 45 || attempt == 50 || attempt == 51 || attempt == 56)
            {
                bigBoxCounter[21]++;
            }
            if(attempt == 46 || attempt == 51 || attempt == 52 || attempt == 57)
            {
                bigBoxCounter[22]++;
            }
            if(attempt == 47 || attempt == 52 || attempt == 53 || attempt == 58)
            {
                bigBoxCounter[23]++;
            }
            if(attempt == 48 || attempt == 53 || attempt == 54 || attempt == 59)
            {
                bigBoxCounter[24]++;
            }
            if(attempt == 49 || attempt == 54 || attempt == 55 || attempt == 60)
            {
                bigBoxCounter[25]++;
            }
        }



            
            if(attempt == 1 || attempt == 6 || attempt == 7 || attempt == 12)
            {
                bigBoxCounter[1]++;
            }
            if(attempt == 2 || attempt == 7 || attempt == 8 || attempt == 13)
            {
                bigBoxCounter[2]++;
            }
            if(attempt == 3 || attempt == 8 || attempt == 9 || attempt == 14)
            {
                bigBoxCounter[3]++;
            }
            if(attempt == 4 || attempt == 9 || attempt == 10 || attempt == 15)
            {
                bigBoxCounter[4]++;
            }
            if(attempt == 5 || attempt == 10 || attempt == 11 || attempt == 16)
            {
                bigBoxCounter[5]++;
            }
            if(attempt == 12 || attempt == 17 || attempt == 18 || attempt == 23)
            {
                bigBoxCounter[6]++;
            }
            if(attempt == 13 || attempt == 18 || attempt == 19 || attempt == 24)
            {
                bigBoxCounter[7]++;
            }
            if(attempt == 14 || attempt == 19 || attempt == 20 || attempt == 25)
            {
                bigBoxCounter[8]++;
            }
            if(attempt == 15 || attempt == 20 || attempt == 21 || attempt == 26)
            {
                bigBoxCounter[9]++;
            }
            if(attempt == 16 || attempt == 21 || attempt == 22 || attempt == 27)
            {
                bigBoxCounter[10]++;
            }
            if(attempt == 23 || attempt == 28 || attempt == 29 || attempt == 34)
            {
                bigBoxCounter[11]++;
            }
            if(attempt == 24 || attempt == 29 || attempt == 30 || attempt == 35)
            {
                bigBoxCounter[12]++;
            }
            if(attempt == 25 || attempt == 30 || attempt == 31 || attempt == 36)
            {
                bigBoxCounter[13]++;
            }
            if(attempt == 26 || attempt == 31 || attempt == 32 || attempt == 37)
            {
                bigBoxCounter[14]++;
            }
            if(attempt == 27 || attempt == 32 || attempt == 33 || attempt == 38)
            {
                bigBoxCounter[15]++;
            }
            if(attempt == 34 || attempt == 39 || attempt == 40 || attempt == 45)
            {
                bigBoxCounter[16]++;
            }
            if(attempt == 35 || attempt == 40 || attempt == 41 || attempt == 46)
            {
                bigBoxCounter[17]++;
            }
            if(attempt == 36 || attempt == 41 || attempt == 42 || attempt == 47)
            {
                bigBoxCounter[18]++;
            }
            if(attempt == 37 || attempt == 42 || attempt == 43 || attempt == 48)
            {
                bigBoxCounter[19]++;
            }
            if(attempt == 38|| attempt == 43 || attempt == 44 || attempt == 49)
            {
                bigBoxCounter[20]++;
            }
            if(attempt == 45 || attempt == 50 || attempt == 51 || attempt == 56)
            {
                bigBoxCounter[21]++;
            }
            if(attempt == 46 || attempt == 51 || attempt == 52 || attempt == 57)
            {
                bigBoxCounter[22]++;
            }
            if(attempt == 47 || attempt == 52 || attempt == 53 || attempt == 58)
            {
                bigBoxCounter[23]++;
            }
            if(attempt == 48 || attempt == 53 || attempt == 54 || attempt == 59)
            {
                bigBoxCounter[24]++;
            }
            if(attempt == 49 || attempt == 54 || attempt == 55 || attempt == 60)
            {
                bigBoxCounter[25]++;
            }
            if(attempt == 27 || attempt == 32 || attempt == 33 || attempt == 38)
            {
                bigBoxCounter[26]++;
            }
            if(attempt == 34 || attempt == 39 || attempt == 40 || attempt == 45)
            {
                bigBoxCounter[27]++;
            }
            if(attempt == 35 || attempt == 40 || attempt == 41 || attempt == 46)
            {
                bigBoxCounter[28]++;
            }
            if(attempt == 36 || attempt == 41 || attempt == 42 || attempt == 47)
            {
                bigBoxCounter[29]++;
            }
            if(attempt == 37 || attempt == 42 || attempt == 43 || attempt == 48)
            {
                bigBoxCounter[30]++;
            }
            if(attempt == 38|| attempt == 43 || attempt == 44 || attempt == 49)
            {
                bigBoxCounter[31]++;
            }
            if(attempt == 45 || attempt == 50 || attempt == 51 || attempt == 56)
            {
                bigBoxCounter[32]++;
            }
            if(attempt == 46 || attempt == 51 || attempt == 52 || attempt == 57)
            {
                bigBoxCounter[33]++;
            }
            if(attempt == 47 || attempt == 52 || attempt == 53 || attempt == 58)
            {
                bigBoxCounter[34]++;
            }
            if(attempt == 48 || attempt == 53 || attempt == 54 || attempt == 59)
            {
                bigBoxCounter[35]++;
            }
            if(attempt == 49 || attempt == 54 || attempt == 55 || attempt == 60)
            {
                bigBoxCounter[36]++;
            }
        }
            
            
        



















































//b3 2x2 over flows to c1
package Alu;

/**
 * Box
 * @author Ryan Alu, Saint Francis University
 * Nov 26, 2017
 */

import java.util.Scanner;


public class BoxGame
{
    private String[] board;
    private String name;
    private int level;
    private int counter;
    private int size;
    private int[] bigBoxCounter;
    private int playerScore;
    private int computerScore;
    
    public BoxGame()
    {
       board = new String[145];
       name = "";
       level = -1;
       counter = 1;
       size = 0;
       bigBoxCounter = new int[65];
       playerScore = 0;
       computerScore = 0;   
    }
    
    public BoxGame(BoxGame original)
    {
        name = original.name;
        level = original.level;
        counter = original.counter;
        size = original.size;
        board = new String[145];
        bigBoxCounter = original.bigBoxCounter;
        playerScore = original.playerScore;
        computerScore = original.playerScore;
        for (int i = 1; i < 144; i++)
        {
            board[i] = original.board[i];
        }   
    }
    
    
    public void initialize()
    {
        int num=1;
        
        Scanner input = new Scanner (System.in);
        System.out.println("What is your name challenger?");
        name = input.next();
        System.out.println("Welcome " + name);
        System.out.println();
        
        while (size< 2 || size > 9)
        {
            System.out.println("Size of Board (2-9)?");
            size = input.nextInt();
        }
        
        System.out.println("Board Size: " + size + "X" + size);
        System.out.println();     
        
        
        if(size == 2)
        {
            for (int e=1; e<=1; e++)
            {
                for (int i=1; i<=1; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
                for (int k=1; k<=2; k++)
                {
                    board[num] = "" + k;
                    num++;
                }
            }
            for (int i=1; i<=1; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
            
            while(level <0 || level>3)
            {
                System.out.println("Choose Difficulty (0-3)");
                level = input.nextInt();
            }
        }
        if(size == 3)
        {
            for (int e=1; e<=2; e++)
            {
                for (int i=1; i<=2; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
                for (int k=1; k<=3; k++)
                {
                    board[num] = "" + k;
                    num++;
                }
            }
            for (int i=1; i<=2; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
            
            while(level <0 || level>11)
            {
                System.out.println("Choose Difficulty (0-11)");
                level = input.nextInt();
            }
        }
        if(size == 4)
        {
            for (int e=1; e<=3; e++)
            {
                for (int i=1; i<=3; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
                for (int k=1; k<=4; k++)
                {
                    board[num] = "" + k;
                    num++;
                }
            }
            for (int i=1; i<=3; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
            while(level<0 || level>23)
            {
                System.out.println("Choose Difficulty (0-23)");
                level = input.nextInt();
            }
        }
        if(size == 5)
        {
            for (int e=1; e<=4; e++)
            {
                for (int i=1; i<=4; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
                for (int k=1; k<=5; k++)
                {
                    board[num] = "" + k;
                    num++;
                }
            }
            for (int i=1; i<=4; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
            
            while(level<0 || level>39)
            {
                System.out.println("Choose Difficulty (0-40)");
                level = input.nextInt();
            }
        }
        if(size == 6)
        {
            for (int e=1; e<=5; e++)
            {
                for (int i=1; i<=5; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
                for (int k=1; k<=6; k++)
                {
                    board[num] = "" + k;
                    num++;
                }
            }
            for (int i=1; i<=5; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
            
            while(level<0 || level>59)
            {
                System.out.println("Choose Difficulty (0-60)");
                level = input.nextInt();
            }
        }
        if(size == 7)
        {
            for (int e=1; e<=6; e++)
            {
                for (int i=1; i<=6; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
                for (int k=1; k<=7; k++)
                {
                    board[num] = "" + k;
                    num++;
                }
            }
            for (int i=1; i<=6; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
            
            while(level<0 || level>83)
            {
                System.out.println("Choose Difficulty (0-84)");
                level = input.nextInt();
            }
        }
        if(size == 8)
        {
            for (int e=1; e<=7; e++)
            {
                for (int i=1; i<=7; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
                for (int k=1; k<=8; k++)
                {
                    board[num] = "" + k;
                    num++;
                }
            }
            for (int i=1; i<=7; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
            
            while(level<0 || level>111)
            {
                System.out.println("Choose Difficulty (0-112)");
                level = input.nextInt();
            }
        }
        if(size == 9)
        {
            for (int e=1; e<=8; e++)
            {
                for (int i=1; i<=8; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
                for (int k=1; k<=9; k++)
                {
                    board[num] = "" + k;
                    num++;
                }
            }
            for (int i=1; i<=8; i++)
                {
                    board[num] = "" + i;
                    num++;
                }
            
            while(level<0 || level>143)
            {
                System.out.println("Choose Difficulty (0-143)");
                level = input.nextInt();
            }
        }     
    }//initialize
    
    public void printBoard()
    {
        String rows = "ABCDEFGHIJKLMNOPQ ";
        int rowName = 0;
        int num = 1;
        for(int j=1; j<size; j++)
        {
            System.out.print(rows.substring(rowName, rowName+1) + "  ");
            for(int i=1; i<size; i++)
            {
                System.out.print("X" + " " + board[num] + " ");
                num++;
            }
            System.out.println("X");
            rowName++;
            
            System.out.print(rows.substring(rowName, rowName+1) + "  ");
            for(int k=1; k<size; k++)
            {
                System.out.print(board[num]);
                System.out.print("   ");
                num++;
            }    
            System.out.println(board[num]);
            num++;
            rowName++;
        }
        System.out.print(rows.substring(rowName, rowName+1) + "  ");
        for(int i=1; i<size; i++)
            {
                System.out.print("X" + " " + board[num] + " ");
                num++;
            }
            System.out.println("X");       
    }
    
    public boolean whoseMove()
    {
        return counter % 2 == 1;
    }
    
    public boolean legalMove(int pos)
    {
    //Determines if a move is legal. A move is legal if it is on the board (between 1 and 9) and if the spot is not already taken by an X or O.
        if(board[pos].equals("|") || board[pos].equals("-"))
        {
            return false;
        }
        
        if(size == 2)
        {
            if(pos<1 || pos>4)
            {
                return false;
            }
        }
        if(size == 3)
        {
            if(pos<1 || pos>12)
            {
                return false;
            }
        }
        if(size == 4)
        {
            if(pos<1 || pos>24)
            {
                return false;
            }
        }
        if(size == 5)
        {
            if(pos<1 || pos>40)
            {
                return false;
            }
        }
        if(size == 6)
        {
            if(pos<1 || pos>60)
            {
                return false;
            }
        }
        if(size == 7)
        {
            if(pos<1 || pos>84)
            {
                return false;
            }
        }
        if(size == 8)
        {
            if(pos<1 || pos>112)
            {
                return false;
            }
        }
        if(size == 9)
        {
            if(pos<1 || pos>144)
            {
                return false;
            }
        }
        return true;
    }
    
    public void updateGame(int spot)
    {
    //Updates the game with a move. X if it's the players move and O if its the computers move. Based on whoseMove which is based on the counter.
        if(size == 2)
        {
            if(spot==1 ||
               spot==4)
            {
                board[spot] = "-";
            }
            else
            {
                board[spot] = "|";
            }
        }
        if(size == 3)
        {
            if(spot==1 || spot==2 || 
               spot==6 || spot==7 ||
               spot==11 || spot==12)
            {
                board[spot] = "-";
            }
            else
            {
                board[spot] = "|";
            }
        }
        if(size == 4)
        {
            if(spot==1 || spot==2 || spot==3 ||
               spot==8 || spot==9 || spot==10 ||
               spot==15 || spot==16 || spot==17 ||
               spot==22 || spot==23 || spot==24)
            {
                board[spot] = "-";
            }
            else
            {
                board[spot] = "|";
            }
        }
        if(size == 5)
        {
            if(spot==1 || spot==2 || spot==3 || spot==4 ||
               spot==10 || spot==11 || spot==12 || spot==13 ||
               spot==19 || spot==20 || spot==21 || spot==22 ||
               spot==28 || spot==29 || spot==30 || spot==31 ||
               spot==37 || spot==38 || spot==39 || spot==40)
            {
                board[spot] = "-";
            }
            else
            {
                board[spot] = "|";
            }
        }
        if(size == 6)
        {
            if(spot==1 || spot==2 || spot==3 || spot==4 || spot==5 ||
               spot==12 || spot==13 || spot==14 || spot==15 || spot==16 ||
               spot==23 || spot==24 || spot==25 || spot==26 || spot==27 ||
               spot==34 || spot==35 || spot==36 || spot==37 || spot==38 ||
               spot==45 || spot==46 || spot==47 || spot==48 || spot==49 ||
               spot==56 || spot==57 || spot==58 || spot==59 || spot==60)
            {
                board[spot] = "-";
            }
            else
            {
                board[spot] = "|";
            }
        }
        if(size == 7)
        {
            if(spot==1 || spot==2 || spot==3 || spot==4 || spot==5 || spot==6 ||
               spot==14 || spot==15 || spot==16 || spot==17 || spot==18 || spot==19 ||
               spot==27 || spot==28 || spot==29 || spot==30 || spot==31 || spot==32 ||
               spot==40 || spot==41 || spot==42 || spot==43 || spot==44 || spot==45 ||
               spot==53 || spot==54 || spot==55 || spot==56 || spot==57 || spot==58 ||
               spot==66 || spot==67 || spot==68 || spot==69 || spot==70 || spot==71 ||
               spot==79 || spot==80 || spot==81 || spot==82 || spot==83 || spot==84)
            {
                board[spot] = "-";
            }
            else
            {
                board[spot] = "|";
            }
        }
        if(size == 8)
        {
            if(spot==1 || spot==2 || spot==3 || spot==4 || spot==5 || spot==6 || spot==7 ||
               spot==16 || spot==17 || spot==18 || spot==19 || spot==20 || spot==21 || spot==22 ||
               spot==31 || spot==32 || spot==33 || spot==34 || spot==35 || spot==36 || spot==37 ||
               spot==46 || spot==47 || spot==48 || spot==49 || spot==50 || spot==51 || spot==52 ||
               spot==61 || spot==62 || spot==63 || spot==64 || spot==65 || spot==66 || spot==67 ||
               spot==76 || spot==77 || spot==78 || spot==79 || spot==80 || spot==81 || spot==82 ||
               spot==91 || spot==92 || spot==93 || spot==94 || spot==95 || spot==96 || spot==97 ||
               spot==106 || spot==107 || spot==108 || spot==109 || spot==110 || spot==111 || spot==112)
            {
                board[spot] = "-";
            }
            else
            {
                board[spot] = "|";
            }
        }
        if(size == 9)
        {
            if(spot==1 || spot==2 || spot==3 || spot==4 || spot==5 || spot==6 || spot==7 || spot==8 ||
               spot==18 || spot==19 || spot==20 || spot==21 || spot==22 || spot==23 || spot==24 || spot==25 ||
               spot==35 || spot==36 || spot==37 || spot==38 || spot==39 || spot==40 || spot==41 || spot==42 ||
               spot==52 || spot==53 || spot==54 || spot==55 || spot==56 || spot==57 || spot==58 || spot==59 ||
               spot==69 || spot==70 || spot==71 || spot==72 || spot==73 || spot==74 || spot==75 || spot==76 ||
               spot==86 || spot==87 || spot==88 || spot==89 || spot==90 || spot==91 || spot==92 || spot==93 ||
               spot==103 || spot==104 || spot==105 || spot==106 || spot==107 || spot==108 || spot==109 || spot==110 ||
               spot==120 || spot==121 || spot==122 || spot==123 || spot==124 || spot==125 || spot==126 || spot==127 ||
               spot==137 || spot==138 || spot==139 || spot==140 || spot==141 || spot==142 || spot==143 || spot==144)
            {
                board[spot] = "-";
            }
            else
            {
                board[spot] = "|";
            }
        }
        
        int a=1;
        int f = (size-1);
        int b=(a+f);
        int c=(b+1);
        int d=(c+f);
        int e=1;    
        
        for(int j=1; j<=f; j++)
        {    
            for(int i=1; i<=f; i++)
            {
                if(spot == a || spot == b || spot == c || spot == d)
                {
                    bigBoxCounter[e]++;
                }
                a++;
                b++;
                c++;
                d++;
                e++;                          
            }
                a=(a+size);
                b=(b+size);
                c=(c+size);
                d=(d+size);  
        }
        
        if(didHeScore(spot) == true)
        {
            counter--;
        }
        counter++;
    }
    
    public boolean finalSituation()
    {
        if(size==2)
        {
            if (playerScore + computerScore == 1)
            {
                return true;
            }
        }
        if(size==3)
        {
            if (playerScore + computerScore == 4)
            {
                return true;
            }
        }
        if(size==4)
        {
            if (playerScore + computerScore == 9)
            {
                return true;
            }
        }
        if(size==5)
        {
            if (playerScore + computerScore == 16)
            {
                return true;
            }
        }
        if(size==6)
        {
            if (playerScore + computerScore == 25)
            {
                return true;
            }
        }
        if(size==7)
        {
            if (playerScore + computerScore == 36)
            {
                return true;
            }
        }
        if(size==8)
        {
            if (playerScore + computerScore == 49)
            {
                return true;
            }
        }
        if(size==9)
        {
            if (playerScore + computerScore == 64)
            {
                return true;
            }
        }
        return false;
    }
    
    public int playerMove()
    {
        Scanner enter = new Scanner (System.in);
        System.out.println("Where do you chose to play your move, " + name + " ?");
        System.out.println("Remember: First letter = row(including spaces). Second number = column");
        String userAnswer = enter.next();
        
        String userLetter = userAnswer.substring(0, 1);
        String userNumber = userAnswer.substring(1, 2);
        
        
        if(size == 2)
        {
            if(userLetter.equals("a") || userLetter.equals("A"))
            {
                return Integer.parseInt(userNumber);
            }
            if(userLetter.equals("b") || userLetter.equals("B"))
            {
                return (1 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("c") || userLetter.equals("C"))
            {
                return (3 + Integer.parseInt(userNumber));
            }
            else
            {
                return -1;
            }
        }
        if(size == 3)
        {
            if(userLetter.equals("a") || userLetter.equals("A"))
            {
                return Integer.parseInt(userNumber);
            }
            if(userLetter.equals("b") || userLetter.equals("B"))
            {
                return (2 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("c") || userLetter.equals("C"))
            {
                return (5 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("d") || userLetter.equals("D"))
            {
                return (7 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("e") || userLetter.equals("E"))
            {
                return (10 + Integer.parseInt(userNumber));
            }
            else
            {
                return -1;
            }
        }
        if(size == 4)
        {
            if(userLetter.equals("a") || userLetter.equals("A"))
            {
                return Integer.parseInt(userNumber);
            }
            if(userLetter.equals("b") || userLetter.equals("B"))
            {
                return (3 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("c") || userLetter.equals("C"))
            {
                return (7 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("d") || userLetter.equals("D"))
            {
                return (10 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("e") || userLetter.equals("E"))
            {
                return (14 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("f") || userLetter.equals("F"))
            {
                return (17 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("g") || userLetter.equals("G"))
            {
                return (21 + Integer.parseInt(userNumber));
            }
            else
            {
                return -1;
            }
        }
        if(size == 5)
        {
            if(userLetter.equals("a") || userLetter.equals("A"))
            {
                return Integer.parseInt(userNumber);
            }
            if(userLetter.equals("b") || userLetter.equals("B"))
            {
                return (4 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("c") || userLetter.equals("C"))
            {
                return (9 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("d") || userLetter.equals("D"))
            {
                return (13 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("e") || userLetter.equals("E"))
            {
                return (18 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("f") || userLetter.equals("F"))
            {
                return (22 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("g") || userLetter.equals("G"))
            {
                return (27 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("h") || userLetter.equals("H"))
            {
                return (31 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("i") || userLetter.equals("I"))
            {
                return (36 + Integer.parseInt(userNumber));
            }
            else
            {
                return -1;
            }
        }
        if(size == 6)
        {
            if(userLetter.equals("a") || userLetter.equals("A"))
            {
                return Integer.parseInt(userNumber);
            }
            if(userLetter.equals("b") || userLetter.equals("B"))
            {
                return (5 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("c") || userLetter.equals("C"))
            {
                return (11 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("d") || userLetter.equals("D"))
            {
                return (16 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("e") || userLetter.equals("E"))
            {
                return (22 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("f") || userLetter.equals("F"))
            {
                return (27 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("g") || userLetter.equals("G"))
            {
                return (33 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("h") || userLetter.equals("H"))
            {
                return (38 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("i") || userLetter.equals("I"))
            {
                return (44 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("j") || userLetter.equals("J"))
            {
                return (49 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("k") || userLetter.equals("K"))
            {
                return (55 + Integer.parseInt(userNumber));
            }
            else
            {
                return -1;
            }
        }
        if(size == 7)
        {
            if(userLetter.equals("a") || userLetter.equals("A"))
            {
                return Integer.parseInt(userNumber);
            }
            if(userLetter.equals("b") || userLetter.equals("B"))
            {
                return (6 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("c") || userLetter.equals("C"))
            {
                return (13 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("d") || userLetter.equals("D"))
            {
                return (19 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("e") || userLetter.equals("E"))
            {
                return (26 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("f") || userLetter.equals("F"))
            {
                return (32 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("g") || userLetter.equals("G"))
            {
                return (39 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("h") || userLetter.equals("H"))
            {
                return (45 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("i") || userLetter.equals("I"))
            {
                return (52 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("j") || userLetter.equals("J"))
            {
                return (58 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("k") || userLetter.equals("K"))
            {
                return (65 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("l") || userLetter.equals("L"))
            {
                return (71 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("m") || userLetter.equals("M"))
            {
                return (78 + Integer.parseInt(userNumber));
            }
            else
            {
                return -1;
            }
        }
        if(size == 8)
        {
            if(userLetter.equals("a") || userLetter.equals("A"))
            {
                return Integer.parseInt(userNumber);
            }
            if(userLetter.equals("b") || userLetter.equals("B"))
            {
                return (7 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("c") || userLetter.equals("C"))
            {
                return (15 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("d") || userLetter.equals("D"))
            {
                return (22 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("e") || userLetter.equals("E"))
            {
                return (30 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("f") || userLetter.equals("F"))
            {
                return (37 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("g") || userLetter.equals("G"))
            {
                return (45 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("h") || userLetter.equals("H"))
            {
                return (52 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("i") || userLetter.equals("I"))
            {
                return (60 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("j") || userLetter.equals("J"))
            {
                return (67 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("k") || userLetter.equals("K"))
            {
                return (75 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("l") || userLetter.equals("L"))
            {
                return (82 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("m") || userLetter.equals("M"))
            {
                return (90 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("n") || userLetter.equals("N"))
            {
                return (97 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("o") || userLetter.equals("O"))
            {
                return (105 + Integer.parseInt(userNumber));
            }
            else
            {
                return -1;
            }
        }
        if(size == 9)
        {
            if(userLetter.equals("a") || userLetter.equals("A"))
            {
                return Integer.parseInt(userNumber);
            }
            if(userLetter.equals("b") || userLetter.equals("B"))
            {
                return (8 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("c") || userLetter.equals("C"))
            {
                return (17 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("d") || userLetter.equals("D"))
            {
                return (25 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("e") || userLetter.equals("E"))
            {
                return (34 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("f") || userLetter.equals("F"))
            {
                return (42 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("g") || userLetter.equals("G"))
            {
                return (51 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("h") || userLetter.equals("H"))
            {
                return (59 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("i") || userLetter.equals("I"))
            {
                return (68 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("j") || userLetter.equals("J"))
            {
                return (76 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("k") || userLetter.equals("K"))
            {
                return (85 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("l") || userLetter.equals("L"))
            {
                return (93 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("m") || userLetter.equals("M"))
            {
                return (102 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("n") || userLetter.equals("N"))
            {
                return (110 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("o") || userLetter.equals("O"))
            {
                return (119 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("p") || userLetter.equals("P"))
            {
                return (127 + Integer.parseInt(userNumber));
            }
            if(userLetter.equals("q") || userLetter.equals("Q"))
            {
                return (136 + Integer.parseInt(userNumber));
            }
            else
            {
                return -1;
            }
        }
        else
        {
            return -1;
        }
    }
    
    public int computerMove()
    {
        return bestMove();
    }
    
    public int judge()
    {
        if(playerScore>computerScore)
        {
            return 0;
        }
        if(computerScore>playerScore)
        {
            return 100;
        }
        else
        {
            return 50;
        }
    }
    
    public void result()
    {
        if(playerScore > computerScore)
        {
            System.out.println("PLAYER WINS!");
        }
        if(computerScore > playerScore)
        {
            System.out.println("COMPUTER WINS :(");
        }
    }
    
    public boolean didHeScore(int attempt) //Set of sets. If larger box set contains smaller position space and if all smaller positions spaces = - or | ----- then true
    {
        for(int i=1; i<=64; i++)
        {
            if(bigBoxCounter[i]==4)
            {
                bigBoxCounter[i] = -1;
                if((counter % 2) == 1)
                {
                    playerScore++;
                }
                else
                {
                    computerScore++;
                }
                return true;
            }
        }
        return false;
    }
    
    public int bestMove()
    {
    //Calls best guess and returns where the computer should move.
        int v, w;
        int best;
        int tryMove = 0;
        BoxGame tempSituation;
        
        //Create a copy of the game.
        tempSituation = new BoxGame(this);
        
        //Get the first legal move (there is at least one).
        for(int i=1; i<145; i++)
        {
            if(legalMove(i))
            {
                tryMove = i;
                break;
            } 
        }
        
        //Update the copy of the game with the first legal move and evaluate the situation.
        tempSituation.updateGame(tryMove);
        v = tempSituation.bestGuess(level);
        best = tryMove;
        tryMove++;
        
        //Process all remaining possible moves.
        while(tryMove < 145)
        {
            //Get the next legal move.
            for(; tryMove < 145; tryMove++)
            {
                if(legalMove(tryMove))
                    break;
            }
            if (tryMove == 145) break;
            
            //Make a copy of the situation and try the move that was just found.
            tempSituation = new BoxGame(this);
            tempSituation.updateGame(tryMove);
            
            w = tempSituation.bestGuess(level);
            
            //Update v and best the most recent move was better.
            if((!whoseMove() && (w > v)) || ((whoseMove()) && (w < v)))
            {
                v = w;
                best = tryMove;
            }
            //Go again until tryMove is outside the possible choices (past 9).
            tryMove++;
        }
        return best;
    }//bestMove
            
    public int bestGuess(int level)
    {
    //Looks ahead and determines what move is the best to take.
        int tryMove = 0;
        int v, w;
        BoxGame tempSituation;
    
        //If the difficulty is set to zero. Just have the computer take the next availabke move in order from position 1-9.
        if((level == 0) || finalSituation())
        {
            return judge();
        }
        else
        {
            //Create copy of game.
            tempSituation = new BoxGame(this);
            
            //Get the first legal move (there is at least one).
            for(int i=1; i<145; i++)
            {
                if(legalMove(i))
                {
                    tryMove = i;
                    break;
                } 
            }
            //Update the copy of the game with the first legal move and evaluate the situation. Go down a level because there are 1 less spots to look in the future to.
            tempSituation.updateGame(tryMove);
            v = tempSituation.bestGuess(level - 1);
            tryMove++;
            
            //Process all remaining possible moves.
            while(tryMove < 145)
            {
                //Get the next legal move.
                for(; tryMove <145; tryMove++)
                {
                    if(legalMove(tryMove))
                    {
                        break;
                    }
                }
                if (tryMove == 145) break;
                
                //Make a copy of the situation and try the move that was just found.
                tempSituation = new BoxGame(this);
                tempSituation.updateGame(tryMove);
                
                w = tempSituation.bestGuess(level - 1);
                
                //Update v. v will be the value of the best guess.
                if(!whoseMove())
                {
                    if (v<w)
                    {
                        v = w;
                    }
                    else
                    {
                        v = v;
                    }
                }
                else
                {
                    if(v<w)
                    {
                        v = v;
                    }
                    else
                    {
                        v = w;
                    }
                }
                tryMove++;
            }
            return v;
        }
    }//bestguess
    
    
}











































package Alu;

import java.util.Scanner;

/**
 * Box
 * @author Ryan Alu, Saint Francis University
 * Nov 26, 2017
 */

public class BoxGameTester
{
    public static void main (String [] args)
    {
        int choice;
        Scanner enter = new Scanner (System.in);
        
        //Start the game up and show the board
        BoxGame game = new BoxGame();
        game.initialize();
        game.printBoard();
        
        while(!game.finalSituation())
        //While the game is not over ask the player where he wants to move and save his choice to int choice.
        {
            choice = game.playerMove();            
            
            while(!game.legalMove(choice))
            //If the player did not pick a legal move, ask again.
            {
                game.printBoard();
                System.out.println("Where do you chose to play your move?");
                choice = game.playerMove();
            }
            
            //Update the game and print the board.
            game.updateGame(choice);
            game.printBoard();
            System.out.println();
            
            
            if(!game.finalSituation())
            //If the game is not over let the computer go.
            {
                game.updateGame(game.computerMove());
            }
            game.printBoard();
        }
        //Game is over. Show the final board and give the result.
        System.out.println("Final Board Outcome");
        game.result();
    }
}   
