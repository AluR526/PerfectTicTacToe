package alu;

import java.util.Scanner;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 * TacToe
 * @author Ryan Alu, Saint Francis University
 * Sep 26, 2017
 */

public class Tac extends JFrame implements ActionListener
{
//Instance Fields
//Consists of creating the 3x3 button user interface.
    private TButton buttons[];
    private String names[] = {"1","2","3","4","5","6","7","8","9"};
    private boolean toggle = true;
    private Container container;
    private GridLayout grid;

//Consists of creating the board (an array) that holds strings, player name, level of dificulty of computer, and the turn counter.    
    private static final int MAX = 10;
    private String[] board;
    private String name;
    private int level;
    private int counter;
    private int move;
    
//Constructor
// Board array has 10 spaces, name is and empty string, level equals an invalid number 99 (will be changed) and counter naturally starts at one.
    public Tac()
    {
       super("Controller");
       board = new String[MAX];
       name = "";
       level = 99;
       counter = 1;
       move = 99;
    }
    
    //Takes a deep copy of the current situation.    
    public Tac(Tac original)
    {
        name = original.name;
        level = original.level;
        counter = original.counter;
        board = new String[MAX];
        for (int i = 1; i < MAX; i++)
            board[i] = original.board[i];   
    }
    
    //Methods
    public void initialize()
    //Sets up the game.
    {
        //Inserts values into board array.
        board[1] = "1";
        board[2] = "2";
        board[3] = "3";
        board[4] = "4";
        board[5] = "5";
        board[6] = "6";
        board[7] = "7";
        board[8] = "8";
        board[9] = "9";
        
        //Asks user for name and welcomes him.
        name = JOptionPane.showInputDialog("What is your name challenger?");
        JOptionPane.showMessageDialog(null, "Welcome " + name);        
        
        //User selects difficulty (inserted in GUI dialog box) (must be between 0 and 8 inclusive).
        while(level < 0 || level > 8)
        {
            String difficulty = JOptionPane.showInputDialog("Choose Difficulty"); 
            level = Integer.parseInt(difficulty);
        }
    }//initialize
    
    public void controller()
    //Sets up the user interface and buttons
    {
        grid = new GridLayout(3,3,5,5);
        container = getContentPane();
        setLayout(grid);
        buttons = new TButton[9];
        
        for(int count=0; count<9; count++)
        {
            buttons[count] = new TButton();
            buttons[count].ident = count;
            buttons[count].isClicked = false;
            buttons[count].addActionListener(this);
            add(buttons[count]);
        }
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500,500);
        setVisible(true);
    }//Controller
    
    public void moveReset()
    //Resets variable move to 99. Used as a stall to wait for player input.
    {
        move = 99;
    }//moveReset()
            
    public int getMove()
    //Returns variable move.
    {
        return move;
    }//getMove()
    
    public int playerMove()
    {
    //Asks where the user wants to move and receives the number the user picks. (RELIC)
        Scanner enter = new Scanner (System.in);
        System.out.println("Where do you chose to play your move, " + name + " ?");
        return enter.nextInt();
    }//playerMove()
    
    public void printBoard()
    //Prints a tic tac toe board. (RELIC)
    {
        System.out.println(board[1] + "|" + board[2] + "|" + board[3]);
        System.out.println(board[4] + "|" + board[5] + "|" + board[6]);
        System.out.println(board[7] + "|" + board[8] + "|" + board[9]);
    }//printBoard
    
    //trturns true if it is the human's move and false if it is the computer's move
    public boolean whoseMove()
    {
        return counter % 2 == 1;    //odd numbered moves are the player's
    }//whoseMove()
    
    public boolean legalMove(int pos)
    {
    //Determines if a move is legal. A move is legal if it is on the board (between 1 and 9) and if the spot is not already taken by an X or O.
        return !(pos > 9 || pos < 1 || board[pos].equals("X") || board[pos].equals("O"));
    }//legalMove
    
    public void updateGame(int spot)
    {
    //Updates the game with a move. X if it's the players move and O if its the computers move. Based on whoseMove which is based on the counter.
        if (whoseMove())
        {
            board[spot] = "X";
        }
        else
        {
            board[spot] = "O";
        }
        counter++;
    }//updateGame
    
    public boolean finalSituation()
    {
    //Determines if the game is over. Game is over if there is a three in a row of X's or O's or if 9 moves have been made (a tie).
        return (board[1].equals("X") && board[2].equals("X") && board[3].equals("X")) ||
                (board[4].equals("X") && board[5].equals("X") && board[6].equals("X")) ||
                (board[7].equals("X") && board[8].equals("X") && board[9].equals("X")) ||
                (board[1].equals("X") && board[5].equals("X") && board[9].equals("X")) ||
                (board[1].equals("X") && board[4].equals("X") && board[7].equals("X")) ||
                (board[2].equals("X") && board[5].equals("X") && board[8].equals("X")) ||
                (board[3].equals("X") && board[6].equals("X") && board[9].equals("X")) ||
                (board[3].equals("X") && board[5].equals("X") && board[7].equals("X")) ||
                (board[1].equals("O") && board[2].equals("O") && board[3].equals("O")) ||
                (board[4].equals("O") && board[5].equals("O") && board[6].equals("O")) ||
                (board[7].equals("O") && board[8].equals("O") && board[9].equals("O")) ||
                (board[1].equals("O") && board[5].equals("O") && board[9].equals("O")) ||
                (board[3].equals("O") && board[5].equals("O") && board[7].equals("O")) ||
                (board[1].equals("O") && board[4].equals("O") && board[7].equals("O")) ||
                (board[2].equals("O") && board[5].equals("O") && board[8].equals("O")) ||
                (board[3].equals("O") && board[6].equals("O") && board[9].equals("O")) ||
                counter > MAX;
    }
    
    public int computerMove()
    {
    //computer goes where it thinks best. See bestMove().
        int j = bestMove();
        
        if (j != 0)    //bestMove returns 0 if there are no valid moves available
        {
            buttons[j - 1].isClicked = true;
            buttons[j - 1].setText("O");
        }
        
        return j;
    }//computerMove
    
    public int judge()
    {
    //Used for the computer to figure out what move is good and what move is bad to make
        //If the player wins return a 0 (that's a bad outcome).
        if((board[1].equals("X") && board[2].equals("X") && board[3].equals("X")) ||
           (board[4].equals("X") && board[5].equals("X") && board[6].equals("X")) ||
           (board[7].equals("X") && board[8].equals("X") && board[9].equals("X")) ||
           (board[1].equals("X") && board[5].equals("X") && board[9].equals("X")) ||
           (board[1].equals("X") && board[4].equals("X") && board[7].equals("X")) ||
           (board[2].equals("X") && board[5].equals("X") && board[8].equals("X")) ||
           (board[3].equals("X") && board[6].equals("X") && board[9].equals("X")) ||
           (board[3].equals("X") && board[5].equals("X") && board[7].equals("X")))
        {
            return 0;
        }
        //If the computer wins retuen 100 (that's a good outcome).
        else if((board[1].equals("O") && board[2].equals("O") && board[3].equals("O")) ||
           (board[4].equals("O") && board[5].equals("O") && board[6].equals("O")) ||
           (board[7].equals("O") && board[8].equals("O") && board[9].equals("O")) ||
           (board[1].equals("O") && board[5].equals("O") && board[9].equals("O")) ||
           (board[3].equals("O") && board[5].equals("O") && board[7].equals("O")) ||
           (board[1].equals("O") && board[4].equals("O") && board[7].equals("O")) ||
           (board[2].equals("O") && board[5].equals("O") && board[8].equals("O")) ||
           (board[3].equals("O") && board[6].equals("O") && board[9].equals("O")))
        {
            return 100;
        }
        //Other wise just return 50. Do not know if it is a good or bad move.
        else
        {
            return 50;
        }
    }
    
    public void result()
    {
    //Display a message at the end of a game.
        //If the player gets three in a row print out that the player won!
        if((board[1].equals("X") && board[2].equals("X") && board[3].equals("X")) ||
           (board[4].equals("X") && board[5].equals("X") && board[6].equals("X")) ||
           (board[7].equals("X") && board[8].equals("X") && board[9].equals("X")) ||
           (board[1].equals("X") && board[5].equals("X") && board[9].equals("X")) ||
           (board[1].equals("X") && board[4].equals("X") && board[7].equals("X")) ||
           (board[2].equals("X") && board[5].equals("X") && board[8].equals("X")) ||
           (board[3].equals("X") && board[6].equals("X") && board[9].equals("X")) ||
           (board[3].equals("X") && board[5].equals("X") && board[7].equals("X")))
        {
            //System.out.println();
           JOptionPane.showMessageDialog(null, name + " WINS!"); 
        //If the computer gets three in a row print out that the computer won!
        }
        else if((board[1].equals("O") && board[2].equals("O") && board[3].equals("O")) ||
           (board[4].equals("O") && board[5].equals("O") && board[6].equals("O")) ||
           (board[7].equals("O") && board[8].equals("O") && board[9].equals("O")) ||
           (board[1].equals("O") && board[5].equals("O") && board[9].equals("O")) ||
           (board[3].equals("O") && board[5].equals("O") && board[7].equals("O")) ||
           (board[1].equals("O") && board[4].equals("O") && board[7].equals("O")) ||
           (board[2].equals("O") && board[5].equals("O") && board[8].equals("O")) ||
           (board[3].equals("O") && board[6].equals("O") && board[9].equals("O")))
        {
            //System.out.println();
            JOptionPane.showMessageDialog(null, "Computer WINS!");
        }
        //If no one won, print out it was a tie.
        else
        {
            //System.out.println();
            JOptionPane.showMessageDialog(null, "TIE!");
        }
    }
    
    public int bestMove()
    {
    //Calls best guess and returns where the computer should move.
        int v, w;
        int best;
        int tryMove = 0;
        Tac tempSituation;
        
        //Create a copy of the game.
        tempSituation = new Tac(this);
        
        //Get the first legal move (there is at least one).
        for(int i=1; i<MAX; i++)
        {
            if(legalMove(i))
            {
                tryMove = i;
                break;
            } 
        }
        
        //Update the copy of the game with the first legal move and evaluate the situation.
        tempSituation.updateGame(tryMove);
        v = tempSituation.bestGuess(level);
        best = tryMove;
        tryMove++;
        
        //Process all remaining possible moves.
        while(tryMove < MAX)
        {
            //Get the next legal move.
            for(; tryMove < MAX; tryMove++)
            {
                if(legalMove(tryMove))
                    break;
            }
            if (tryMove == MAX) break;
            
            //Make a copy of the situation and try the move that was just found.
            tempSituation = new Tac(this);
            tempSituation.updateGame(tryMove);
            
            w = tempSituation.bestGuess(level);
            
            //Update v and best the most recent move was better.
            if((!whoseMove() && (w > v)) || ((whoseMove()) && (w < v)))
            {
                v = w;
                best = tryMove;
            }
            //Go again until tryMove is outside the possible choices (past 9).
            tryMove++;
        }
        return best;
    }//bestMove
            
    public int bestGuess(int level)
    {
    //Looks ahead and determines what move is the best to take.
        int tryMove = 0;
        int v, w;
        Tac tempSituation;
    
        //If the difficulty is set to zero. Just have the computer take the next availabke move in order from position 1-9.
        if((level == 0) || finalSituation())
        {
            return judge();
        }
        else
        {
            //Create copy of game.
            tempSituation = new Tac(this);
            
            //Get the first legal move (there is at least one).
            for(int i=1; i<MAX; i++)
            {
                if(legalMove(i))
                {
                    tryMove = i;
                    break;
                } 
            }
            //Update the copy of the game with the first legal move and evaluate the situation. Go down a level because there are 1 less spots to look in the future to.
            tempSituation.updateGame(tryMove);
            v = tempSituation.bestGuess(level - 1);
            tryMove++;
            
            //Process all remaining possible moves.
            while(tryMove < MAX)
            {
                //Get the next legal move.
                for(; tryMove <MAX; tryMove++)
                {
                    if(legalMove(tryMove))
                    {
                        break;
                    }
                }
                if (tryMove == MAX) break;
                
                //Make a copy of the situation and try the move that was just found.
                tempSituation = new Tac(this);
                tempSituation.updateGame(tryMove);
                
                w = tempSituation.bestGuess(level - 1);
                
                //Update v. v will be the value of the best guess.
                if(!whoseMove())
                {
                    if (v<w)
                    {
                        v = w;
                    }
                    else
                    {
                        v = v;
                    }
                }
                else
                {
                    if(v < w)  v = v;
                    else       v = w;
                }
                tryMove++;
            }
            return v;
        }
    }//bestguess

    
    @Override
    public void actionPerformed(ActionEvent e)
    //Occurs when user clicks a button. Adjusts move and sets a button to display an "X."
    {
        TButton currentButton = (TButton)(e.getSource());
        move = currentButton.ident + 1;
        currentButton.isClicked = true;
        if(legalMove(move))
        currentButton.setText("X");
    }
}//Tac

